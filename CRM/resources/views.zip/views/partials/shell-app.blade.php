<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'CRM Puerta Principal' }}</title>
    <style>
        :root {
            color-scheme: light;
            --bg: #eef3f9;
            --bg-accent: #f8fbff;
            --panel: rgba(255, 255, 255, 0.86);
            --panel-solid: #ffffff;
            --surface: #f7faff;
            --surface-strong: #edf4ff;
            --text: #142338;
            --muted: #617286;
            --border: rgba(148, 163, 184, 0.24);
            --border-strong: rgba(148, 163, 184, 0.38);
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --primary-soft: rgba(37, 99, 235, 0.12);
            --success: #027a48;
            --success-soft: rgba(2, 122, 72, 0.1);
            --danger: #b42318;
            --danger-soft: rgba(180, 35, 24, 0.1);
            --warning: #8a4b00;
            --warning-soft: rgba(138, 75, 0, 0.1);
            --shadow-sm: 0 8px 20px rgba(15, 23, 42, 0.05);
            --shadow-md: 0 18px 44px rgba(15, 23, 42, 0.08);
            --radius-xl: 24px;
            --radius-lg: 18px;
            --radius-md: 14px;
            --transition: 180ms ease;
        }

        * {
            box-sizing: border-box;
        }

        html,
        body {
            min-height: 100%;
        }

        body {
            margin: 0;
            font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background:
                radial-gradient(circle at top left, rgba(37, 99, 235, 0.12), transparent 26%),
                radial-gradient(circle at top right, rgba(14, 165, 233, 0.08), transparent 24%),
                linear-gradient(180deg, #f8fbff 0%, var(--bg) 100%);
            color: var(--text);
        }

        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background:
                linear-gradient(rgba(255, 255, 255, 0.54), rgba(255, 255, 255, 0)),
                radial-gradient(circle at center, rgba(255, 255, 255, 0.22), transparent 64%);
            pointer-events: none;
            z-index: 0;
        }

        a {
            color: inherit;
        }

        form {
            margin: 0;
        }

        .app-shell {
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        .impersonation-banner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 12px 20px;
            background: linear-gradient(135deg, #fff8ea, #fff4de);
            border-bottom: 1px solid rgba(242, 197, 124, 0.62);
            color: var(--warning);
            font-size: 14px;
        }

        .app-header {
            position: sticky;
            top: 0;
            z-index: 10;
            padding: 18px 20px 0;
        }

        .app-header-inner {
            width: min(1260px, 100%);
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            padding: 18px 20px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: var(--radius-xl);
            background: rgba(255, 255, 255, 0.72);
            box-shadow: var(--shadow-md);
            backdrop-filter: blur(18px);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 0;
        }

        .brand-mark {
            width: 14px;
            height: 14px;
            border-radius: 999px;
            background: linear-gradient(135deg, #2563eb, #06b6d4);
            box-shadow: 0 0 0 8px rgba(37, 99, 235, 0.12);
            flex-shrink: 0;
        }

        .brand-title {
            margin: 0;
            font-size: 18px;
            font-weight: 800;
            letter-spacing: -0.03em;
        }

        .meta {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.55;
        }

        .toolbar {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 12px;
            min-width: 0;
            flex: 1;
            flex-wrap: wrap;
        }

        .toolbar-group {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .button,
        .button-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 42px;
            padding: 10px 16px;
            border-radius: 999px;
            border: 1px solid transparent;
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
            transition: transform var(--transition), background var(--transition), border-color var(--transition), color var(--transition), box-shadow var(--transition);
        }

        .button {
            background: linear-gradient(135deg, var(--primary), #1d4ed8);
            color: #fff;
            box-shadow: 0 12px 24px rgba(37, 99, 235, 0.18);
        }

        .button:hover {
            transform: translateY(-1px);
            box-shadow: 0 16px 28px rgba(37, 99, 235, 0.24);
        }

        .button-link {
            background: rgba(37, 99, 235, 0.08);
            border-color: rgba(37, 99, 235, 0.1);
            color: var(--primary-dark);
        }

        .button-link:hover {
            transform: translateY(-1px);
            background: rgba(37, 99, 235, 0.12);
            border-color: rgba(37, 99, 235, 0.18);
        }

        .button:disabled,
        .button-link:disabled {
            opacity: 0.65;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .app-main {
            padding: 22px 20px 28px;
        }

        .app-container {
            width: min(1260px, 100%);
            margin: 0 auto;
        }

        .card {
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.98), var(--panel-solid));
            border: 1px solid rgba(255, 255, 255, 0.65);
            border-radius: var(--radius-xl);
            padding: 24px;
            box-shadow: var(--shadow-sm);
        }

        h1,
        h2,
        h3 {
            color: var(--text);
            letter-spacing: -0.03em;
        }

        p {
            color: var(--muted);
        }

        input,
        select,
        textarea {
            width: 100%;
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 13px 15px;
            font-size: 14px;
            color: var(--text);
            background: rgba(250, 252, 255, 0.96);
            transition: border-color var(--transition), box-shadow var(--transition), background var(--transition), transform var(--transition);
        }

        input:hover,
        select:hover,
        textarea:hover {
            border-color: var(--border-strong);
            background: #ffffff;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: rgba(37, 99, 235, 0.42);
            background: #ffffff;
            box-shadow: 0 0 0 5px var(--primary-soft);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead th {
            color: #304256;
            font-size: 12px;
            font-weight: 800;
            letter-spacing: 0.04em;
            text-transform: uppercase;
        }

        tbody tr {
            transition: background var(--transition);
        }

        tbody tr:hover {
            background: rgba(37, 99, 235, 0.03);
        }

        .alert {
            padding: 14px 16px;
            border-radius: 18px;
            margin-bottom: 18px;
            font-size: 14px;
            border: 1px solid transparent;
        }

        .alert-danger {
            background: #fff3f2;
            border-color: rgba(180, 35, 24, 0.16);
            color: var(--danger);
        }

        .alert-success {
            background: #effbf4;
            border-color: rgba(2, 122, 72, 0.16);
            color: var(--success);
        }

        .surface {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 10px;
            border-radius: 999px;
            background: var(--primary-soft);
            color: var(--primary-dark);
            font-size: 12px;
            font-weight: 700;
        }

        .empty-state {
            display: grid;
            place-items: center;
            text-align: center;
            min-height: 180px;
            padding: 24px;
            color: var(--muted);
        }

        .page-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 20px;
        }

        .page-header h1 {
            margin: 0 0 8px;
            font-size: 28px;
            line-height: 1.05;
        }

        .page-header p {
            margin: 0;
            font-size: 14px;
        }

        .page-header-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        @media (max-width: 960px) {
            .app-header-inner {
                align-items: flex-start;
                flex-direction: column;
            }

            .toolbar {
                width: 100%;
                justify-content: flex-start;
            }
        }

        @media (max-width: 720px) {
            .app-header,
            .app-main {
                padding-left: 14px;
                padding-right: 14px;
            }

            .app-header-inner,
            .card {
                padding: 18px;
            }

            .impersonation-banner {
                align-items: flex-start;
                flex-direction: column;
            }

            .page-header {
                flex-direction: column;
            }

            .page-header-actions {
                width: 100%;
                justify-content: flex-start;
            }
        }
    </style>
</head>
<body>
    @php
        $currentUser = auth()->user();
        $isImpersonating = session()->has('impersonator_id');
    @endphp

    <div class="app-shell">
        @if ($isImpersonating && $currentUser)
            <div class="impersonation-banner">
                <div>
                    Estas usando la cuenta de <strong>{{ $currentUser->name }}</strong>.
                    Sesion original: <strong>{{ session('impersonator_name') }}</strong>.
                </div>
                <form method="POST" action="{{ route('impersonation.leave') }}">
                    @csrf
                    <button class="button" type="submit">Salir de esta cuenta</button>
                </form>
            </div>
        @endif

        <header class="app-header">
            <div class="app-header-inner">
                <div class="brand">
                    <span class="brand-mark"></span>
                    <div>
                        <div class="brand-title">CRM Puerta Principal</div>
                        @if ($currentUser)
                            <div class="meta">{{ $currentUser->name }} · {{ $currentUser->role }}</div>
                        @endif
                    </div>
                </div>

                <div class="toolbar">
                    <div class="toolbar-group">
                        <a class="button-link" href="{{ route('leads.index') }}">Leads</a>
                        <a class="button-link" href="{{ route('leads.create') }}">Nuevo lead</a>
                        <a class="button-link" href="{{ route('leads.import.create') }}">Importar</a>
                        @if ($currentUser && ($currentUser->isSuperAdmin() || $currentUser->isSupervisor()))
                            <a class="button-link" href="{{ route('metrics.index') }}">Metricas</a>
                        @endif
                        @if ($currentUser && $currentUser->role === \App\Models\User::ROLE_SUPER_ADMIN)
                            <a class="button-link" href="{{ route('users.index') }}">Usuarios</a>
                        @endif
                    </div>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button class="button" type="submit">Salir</button>
                    </form>
                </div>
            </div>
        </header>

        <main class="app-main">
            <div class="app-container">
                {{ $slot }}
            </div>
        </main>
    </div>
</body>
</html>
