<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'CRM Puerta Principal' }}</title>
    <style>
        :root {
            color-scheme: light;
            --bg: #07111f;
            --bg-soft: #0d182b;
            --panel: rgba(255, 255, 255, 0.9);
            --panel-solid: #ffffff;
            --text: #132238;
            --muted: #5e6c7f;
            --border: rgba(140, 162, 189, 0.28);
            --border-strong: rgba(140, 162, 189, 0.42);
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --primary-soft: rgba(37, 99, 235, 0.14);
            --danger: #b42318;
            --danger-soft: rgba(180, 35, 24, 0.1);
            --success: #027a48;
            --success-soft: rgba(2, 122, 72, 0.1);
            --shadow-xl: 0 30px 80px rgba(3, 10, 18, 0.35);
            --shadow-lg: 0 16px 40px rgba(15, 23, 42, 0.16);
            --radius-xl: 28px;
            --radius-lg: 18px;
            --radius-md: 14px;
            --transition: 180ms ease;
        }

        * {
            box-sizing: border-box;
        }

        html,
        body {
            min-height: 100%;
        }

        body {
            margin: 0;
            font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background:
                radial-gradient(circle at top left, rgba(37, 99, 235, 0.24), transparent 32%),
                radial-gradient(circle at bottom right, rgba(14, 165, 233, 0.18), transparent 28%),
                linear-gradient(135deg, var(--bg) 0%, #0b1423 42%, #121f34 100%);
            color: var(--text);
        }

        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
            background-size: 44px 44px;
            mask-image: radial-gradient(circle at center, black, transparent 78%);
            pointer-events: none;
        }

        .wrapper {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 28px;
        }

        .panel {
            width: min(1120px, 100%);
            display: grid;
            grid-template-columns: minmax(320px, 1fr) minmax(420px, 1.05fr);
            border-radius: var(--radius-xl);
            overflow: hidden;
            background: rgba(7, 17, 31, 0.22);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: var(--shadow-xl);
            backdrop-filter: blur(14px);
        }

        .panel-aside {
            position: relative;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            gap: 26px;
            color: rgba(255, 255, 255, 0.92);
            background:
                linear-gradient(180deg, rgba(255, 255, 255, 0.06), rgba(255, 255, 255, 0.02)),
                radial-gradient(circle at top left, rgba(59, 130, 246, 0.28), transparent 34%);
        }

        .panel-aside::after {
            content: '';
            position: absolute;
            inset: 24px;
            border-radius: 22px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            pointer-events: none;
        }

        .brand {
            position: relative;
            z-index: 1;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            font-weight: 700;
            letter-spacing: 0.02em;
            text-transform: uppercase;
        }

        .brand-mark {
            width: 12px;
            height: 12px;
            border-radius: 999px;
            background: linear-gradient(135deg, #60a5fa, #22d3ee);
            box-shadow: 0 0 0 6px rgba(96, 165, 250, 0.14);
        }

        .hero {
            position: relative;
            z-index: 1;
            max-width: 420px;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.12);
            font-size: 12px;
            letter-spacing: 0.04em;
            text-transform: uppercase;
        }

        .hero h2 {
            margin: 18px 0 12px;
            font-size: clamp(30px, 5vw, 46px);
            line-height: 1.02;
            letter-spacing: -0.04em;
        }

        .hero p {
            margin: 0;
            color: rgba(255, 255, 255, 0.72);
            line-height: 1.72;
            font-size: 15px;
        }

        .highlights {
            position: relative;
            z-index: 1;
            display: grid;
            gap: 14px;
        }

        .highlight {
            padding: 16px 18px;
            border-radius: var(--radius-lg);
            background: rgba(255, 255, 255, 0.07);
            border: 1px solid rgba(255, 255, 255, 0.09);
        }

        .highlight strong {
            display: block;
            margin-bottom: 6px;
            font-size: 14px;
        }

        .highlight span {
            color: rgba(255, 255, 255, 0.68);
            font-size: 13px;
            line-height: 1.55;
        }

        .panel-body {
            padding: 40px;
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.96), var(--panel-solid));
        }

        h1 {
            margin: 0 0 12px;
            font-size: 34px;
            line-height: 1.05;
            letter-spacing: -0.04em;
        }

        p {
            margin: 0 0 18px;
            color: var(--muted);
            line-height: 1.65;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
        }

        .field {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .field.full {
            grid-column: 1 / -1;
        }

        label {
            font-size: 13px;
            font-weight: 700;
            color: #1d2f46;
            letter-spacing: 0.01em;
        }

        input,
        select,
        textarea {
            width: 100%;
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 13px 15px;
            font-size: 14px;
            color: var(--text);
            background: rgba(248, 250, 252, 0.94);
            transition: border-color var(--transition), box-shadow var(--transition), background var(--transition), transform var(--transition);
        }

        input:hover,
        select:hover,
        textarea:hover {
            border-color: var(--border-strong);
            background: #ffffff;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: rgba(37, 99, 235, 0.42);
            box-shadow: 0 0 0 5px var(--primary-soft);
            background: #ffffff;
        }

        .actions {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-top: 26px;
        }

        .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 48px;
            border: 0;
            border-radius: 999px;
            background: linear-gradient(135deg, var(--primary), #1d4ed8);
            color: #fff;
            padding: 12px 20px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            box-shadow: 0 12px 24px rgba(37, 99, 235, 0.22);
            transition: transform var(--transition), box-shadow var(--transition), filter var(--transition);
        }

        .button:hover {
            transform: translateY(-1px);
            box-shadow: 0 16px 28px rgba(37, 99, 235, 0.28);
            filter: saturate(1.04);
        }

        .button:disabled {
            cursor: not-allowed;
            opacity: 0.7;
            transform: none;
            box-shadow: none;
        }

        .alert {
            padding: 14px 16px;
            border-radius: 18px;
            margin-bottom: 18px;
            font-size: 14px;
            border: 1px solid transparent;
        }

        .alert-danger {
            background: #fff3f2;
            border-color: rgba(180, 35, 24, 0.16);
            color: var(--danger);
        }

        .alert-success {
            background: #effbf4;
            border-color: rgba(2, 122, 72, 0.16);
            color: var(--success);
        }

        .meta {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.55;
        }

        .list {
            margin: 18px 0 0;
            padding-left: 18px;
            color: var(--muted);
        }

        .list li {
            margin-bottom: 8px;
        }

        @media (max-width: 960px) {
            .panel {
                grid-template-columns: 1fr;
            }

            .panel-aside {
                padding-bottom: 28px;
            }
        }

        @media (max-width: 720px) {
            .wrapper {
                padding: 18px;
            }

            .panel-aside,
            .panel-body {
                padding: 26px;
            }

            .grid {
                grid-template-columns: 1fr;
            }

            .actions {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="panel">
            <aside class="panel-aside">
                <div class="brand">
                    <span class="brand-mark"></span>
                    CRM Puerta Principal
                </div>

                <div class="hero">
                    <div class="eyebrow">Operacion comercial centralizada</div>
                    <h2>Un acceso sobrio, rapido y con mejor presencia visual.</h2>
                    <p>
                        Esta interfaz mantiene la simplicidad del CRM, pero añade profundidad,
                        mejor jerarquia y una sensacion mas fluida para acceso, instalacion y sesiones internas.
                    </p>
                </div>

                <div class="highlights">
                    <div class="highlight">
                        <strong>Claridad operacional</strong>
                        <span>Los formularios siguen siendo directos, pero con foco visual mas limpio y profesional.</span>
                    </div>
                    <div class="highlight">
                        <strong>Transiciones ligeras</strong>
                        <span>Animaciones suaves y cortas para dar fluidez sin afectar rendimiento en hosting compartido.</span>
                    </div>
                </div>
            </aside>

            <div class="panel-body">
                {{ $slot }}
            </div>
        </div>
    </div>
</body>
</html>
