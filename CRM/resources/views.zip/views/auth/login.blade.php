<x-layouts.guest title="Acceso CRM Puerta Principal">
    <x-auth.login-panel
        title="Iniciar sesion"
        eyebrow="Acceso seguro"
        subtitle="Accede con tu correo y contrasena. El reset de contrasena se realiza desde administracion, manteniendo un flujo simple y controlado."
    >
        @if (session('status'))
            <x-ui.alert type="success">{{ session('status') }}</x-ui.alert>
        @endif

        <form method="POST" action="{{ route('login.store') }}" style="display: grid; gap: 18px;">
            @csrf

            <div class="grid">
                <div class="field full">
                    <label for="email">Email</label>
                    <input id="email" name="email" type="email" value="{{ old('email') }}" required autocomplete="username" placeholder="correo@empresa.com">
                    <div class="meta">Usa el correo exacto con el que fue creada tu cuenta en el CRM.</div>
                    @error('email')
                        <div class="meta" style="color: var(--danger);">{{ $message }}</div>
                    @enderror
                </div>

                <div class="field full">
                    <label for="password">Contrasena</label>
                    <input id="password" name="password" type="password" required autocomplete="current-password" placeholder="Ingresa tu contrasena">
                    <div class="meta">El acceso mantiene proteccion contra intentos repetidos y conserva la sesion de trabajo activa.</div>
                    @error('password')
                        <div class="meta" style="color: var(--danger);">{{ $message }}</div>
                    @enderror
                </div>

                <div class="field full" style="flex-direction: row; align-items: center; gap: 12px; padding: 14px 16px; border-radius: 16px; background: rgba(255, 255, 255, 0.75); border: 1px solid rgba(140, 162, 189, 0.16);">
                    <input id="remember" name="remember" type="checkbox" value="1" style="width: auto; margin: 0;">
                    <label for="remember" style="margin: 0; font-weight: 600;">Recordarme en este dispositivo</label>
                </div>
            </div>

            <div class="actions">
                <span class="meta">Si no puedes entrar, solicita al administrador un reset de contrasena y evita compartir cuentas.</span>
                <button class="button" type="submit">Entrar al CRM</button>
            </div>
        </form>
    </x-auth.login-panel>
</x-layouts.guest>
