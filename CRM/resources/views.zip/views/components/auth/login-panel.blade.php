@props([
    'title' => '',
    'subtitle' => null,
    'eyebrow' => null,
])

<section {{ $attributes->merge(['style' => 'display: grid; gap: 24px;']) }}>
    <div style="display: grid; gap: 14px;">
        @if ($eyebrow)
            <div>
                <span class="badge">{{ $eyebrow }}</span>
            </div>
        @endif

        <div>
            <h1>{{ $title }}</h1>
            @if ($subtitle)
                <p style="max-width: 56ch; margin-bottom: 0;">{{ $subtitle }}</p>
            @endif
        </div>
    </div>

    <div style="display: grid; gap: 18px; padding: 22px; border-radius: 22px; background: rgba(248, 250, 252, 0.84); border: 1px solid rgba(140, 162, 189, 0.18); box-shadow: 0 18px 38px rgba(15, 23, 42, 0.08);">
        {{ $slot }}
    </div>
</section>
